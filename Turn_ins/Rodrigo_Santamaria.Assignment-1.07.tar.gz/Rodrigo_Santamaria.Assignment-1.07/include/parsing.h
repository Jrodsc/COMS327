#ifndef PARSING_H
#define PARSING_H
#include <string>

int read_file(std::string file);

#endif
