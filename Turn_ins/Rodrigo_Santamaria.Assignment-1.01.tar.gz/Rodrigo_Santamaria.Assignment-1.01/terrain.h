#ifndef TERRAIN_H
#define TERRAIN_H
#define ROWS 21
#define COLUMNS 84


#endif
